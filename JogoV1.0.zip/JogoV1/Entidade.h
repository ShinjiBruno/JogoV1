#pragma once
#include "Ente.h"

class Entidade: public Ente {
protected:
		 

public:

};