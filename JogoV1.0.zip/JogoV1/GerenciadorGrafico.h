#pragma once
#include "SFML/Graphics.hpp"

class GerenciadorGrafico {
private:


public:
	GerenciadorGrafico();
	~GerenciadorGrafico();

	void desenhar();

};