#pragma once
#include "Lista.h"

namespace Listas {
	class ListaEntidades {

	private:

	public:

	};

}