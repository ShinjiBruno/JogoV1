#include "Personagem.h"
using namespace Entidades;
using namespace Personagens;

Personagem::Personagem(): danar(-1.0f), vida(-1.0f), tempoLoop(T_LOOP) {

}

Personagem::~Personagem() {
	danar = -1.0f;
	vida = -1.0f;
}

float Personagem::calculaGrav() {
	//usar a equacao horaria de posicao: vf = v0 - g.t, onde v0 = sqrt(2.g.H), H eh altura max
	tempoLoop += T_LOOP;

	float H = 0.175f;
	float v0 = sqrt(2 * H);
	float vf = v0 - (tempoLoop);
	return vf;
	
}