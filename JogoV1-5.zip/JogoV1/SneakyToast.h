#pragma once
#include "Inimigo.h"

namespace Entidades {
	namespace Personagens {
		class SneakyToast: public Inimigo {
		private:
			static float ult_increm; //ultimo incremento da posicao
		public:
			SneakyToast();

			Inimigo* clone() {
				return new SneakyToast(*this);
			}
			void configuraInimigo();
			void executar();
		};
	}
}