#pragma once
#include "Obstaculo.h"

namespace Entidades {
	namespace Obstaculos {
		class ObstaculoProjetil : public Obstaculo {
		private:
			static float dif;
		public:
			ObstaculoProjetil();
			~ObstaculoProjetil();
			Obstaculo* clone() {
				return new ObstaculoProjetil(*this);
			}
			void configuraObstaculo();
			void executar();
		};
	}
}