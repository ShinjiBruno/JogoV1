#include "Jogador.h"
using namespace Entidades;
using namespace Personagens;

Jogador::Jogador() {

	figura->setSize(sf::Vector2f(20.0f, 40.0f));
	figura->setOrigin(sf::Vector2f(figura->getSize().x / 2, figura->getSize().y / 2));
	figura->setPosition(sf::Vector2f(100.0f, 200.0f));
	figura->setFillColor(sf::Color::Red);
	andar = 0.15f;
	pulo = false;
	chao = true;
	grav = 0.3f;
}

Jogador::~Jogador() {}

void Jogador::moveJog() {
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
		figura->move(sf::Vector2f(andar, 0));
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
		figura->move(sf::Vector2f(-andar, 0));
	}
	/*if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
		figura->move(sf::Vector2f(0, -andar));
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
		figura->move(sf::Vector2f(0, andar));
	}*/
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && chao) {
		tempoLoop = T_LOOP;
		chao = false;
		pulo = true;
	}
	if (!chao) {
		if (pulo) {
			float velocY = aplicaGrav(1); //opt=1 caso pular
			figura->move(sf::Vector2f(0, -velocY));
		}
		else {
			float velocY = aplicaGrav(2); //opt=2 colisao inimigo
			figura->move(sf::Vector2f(0, -velocY));
		}
	}
	else { figura->move(sf::Vector2f(0, grav)); }//pulo = false; }
	
}

void Jogador::executar() {
	moveJog();
	gGraf->desenhar(*this->figura);
}