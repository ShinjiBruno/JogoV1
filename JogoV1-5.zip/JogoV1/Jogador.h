#pragma once
#include "Personagem.h"

namespace Entidades {
	namespace Personagens {
		class Jogador : public Personagem {
		private:
			sf::RectangleShape barraVida;
			bool pulo;
			int pontos;
		public:
			Jogador();
			~Jogador();

			void moveJog();
			void executar();
		};
	}
}