#pragma once
#include "Obstaculo.h"

namespace Entidades {
	namespace Obstaculos {
		class ObstaculoDanoso : public Obstaculo {
		private:
			static float dif; //diferenca de distancia entre dois obstaculos
		public :
			ObstaculoDanoso();
			~ObstaculoDanoso();

			Obstaculo* clone() {
				return new ObstaculoDanoso(*this);
			}
			void configuraObstaculo();
			void executar();
		};
	}
}