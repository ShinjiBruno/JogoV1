#pragma once
#include "Inimigo.h"

namespace Entidades {
	namespace Personagens {
		class Skull : public Inimigo {
		private:
			static float ult_increm; //ultimo incremento da posicao
		public:
			Skull();

			Inimigo* clone() {
				return new Skull(*this);
			}
			void configuraInimigo();
			void executar();
		};
	}
}