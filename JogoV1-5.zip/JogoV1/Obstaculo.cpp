#include "Obstaculo.h"
using namespace Entidades;
using namespace Obstaculos;

Obstaculo::Obstaculo(): dano(0)
{
	
}

Obstaculo::~Obstaculo() {
}

/*
void Obstaculo::executar() {
	gGraf->desenhar(*this->figura);
}
*/

